TOONPIX AI — STARTER BUILD

What works:
- Mobile-first ToonPix AI interface
- Story idea input
- Character name consistency text
- 6-scene storyboard prompt generation
- Copy all prompts
- PWA manifest and offline cache

What does NOT work yet:
- This is not an AI video renderer.
- No video-generation API is connected.
- No 1080p MP4 export is available yet.
- Unlimited genuinely free AI video generation cannot be promised.

Next stages:
1. Publish this folder as a static website (for example GitHub Pages).
2. Open it in Android Chrome and use Add to Home screen.
3. Connect a legitimate video-generation provider/API after checking its free quota, terms and key security.
4. Add job status, scene previews, voiceover, stitching and MP4 export.
5. Package as APK only after the web app works reliably.

Important:
Never put a private API key in app.js or any public frontend file. A secure backend is needed for private API keys.
