const $=id=>document.getElementById(id);
let lastPrompts=[];
$("make").addEventListener("click",()=>{
 const story=$("story").value.trim();
 if(!story){$("story").focus();alert("Pehle apni story idea likho.");return;}
 const names=$("characters").value.trim()||"Main character";
 const style=$("style").value, format=$("format").value;
 const beats=[
  ["Opening","Introduce the world and the main character. Establish the location, mood and time of day."],
  ["Discovery","The character notices an unusual object or event connected to the story."],
  ["Reaction","Show the character reacting with clear emotion and expressive body language."],
  ["Adventure","The character takes action; show a visually interesting change in the environment."],
  ["Twist","Reveal a surprising but family-friendly development."],
  ["Ending","Resolve the moment with a memorable final shot."]
 ];
 const root=`Story: ${story}\nCharacters: ${names}\nVisual style: ${style}. ${format} composition. Original character designs; expressive faces; polished cinematic lighting; detailed environment; coherent proportions. Keep the exact same character appearance, clothing, colours and accessories in every scene.`;
 lastPrompts=[];
 $("scenes").innerHTML="";
 beats.forEach((b,i)=>{
  const prompt=`${root}\nScene ${i+1} — ${b[0]}: ${b[1]} Create one coherent animated shot. No captions, no logos, no watermarks.`;
  lastPrompts.push(prompt);
  const card=document.createElement("article");card.className="scene";
  const h=document.createElement("h3");h.textContent=`Scene ${String(i+1).padStart(2,"0")} · ${b[0]}`;
  const p=document.createElement("p");p.textContent=b[1];
  const pre=document.createElement("div");pre.className="prompt";pre.textContent=prompt;
  card.append(h,p,pre);$("scenes").append(card);
 });
 $("results").hidden=false;$("results").scrollIntoView({behavior:"smooth"});
});
$("copy").addEventListener("click",async()=>{
 try{await navigator.clipboard.writeText(lastPrompts.join("\n\n"));$("copy").textContent="Copied ✓";}
 catch(e){alert("Clipboard permission unavailable. Select and copy the prompts manually.");}
});
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
